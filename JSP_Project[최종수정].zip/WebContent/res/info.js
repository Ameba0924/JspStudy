jQuery(document).ready(function(){
    //대상 설정
    var slideArea = $("#mousearea"),
        slideDiv = slideArea.siblings("div.info_frame"),
        slideNumber = slideDiv.size(),
        //설정 - 이벤트 드래그 이동량
        dragSize = 50,
        //기본값
        slideCount = 1,
        mDown = false;
    
    
    //마우스 좌클릭 확인
    slideArea.mousedown(function(event){
        mDown = true;
        dragX = event.pageX;
        slideArea.addClass("grab");
    });
    slideArea.mouseup(function(){
        mDown = false;
        slideArea.removeClass("grab");
    });
    
    
    //마우스 드래그 확인
    slideArea.mousemove(function(event){
        
        //마우스가 좌클릭 상태로 마우스를 'dragSize' 이상 이동시
        if(mDown == true && dragX + dragSize < event.pageX){ 
            
            //기준점 재정의
            dragX = event.pageX;
            
            if(slideCount < slideNumber){
                add_remove_class(); //슬라이드 배경 비활성화, 활성화
                slideCount ++;
            }else{
                slideCount = 0;
                add_remove_class();
                slideCount ++;
            }
        }
        if(mDown == true && dragX - dragSize > event.pageX){
                        
            dragX = event.pageX;
            if(0 < slideCount && slideCount){
                slideCount --;
                add_remove_class();
            }else{
                slideCount = slideNumber - 1;
                add_remove_class();
            }
        }
        
    });
 
    //슬라이드 배경 비활성화, 활성화
    function add_remove_class(){ 
        slideDiv.removeClass("active");
        slideDiv.eq(slideCount).addClass("active");
    }
    
});