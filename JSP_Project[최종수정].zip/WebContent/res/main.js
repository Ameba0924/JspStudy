
(function() {
	"use strict";
	$(function($) {
		// Detecting viewpot dimension
		var vH = $(window).height();
		var vW = $(window).width();
		// Adjusting Intro Components Spacing based on detected screen
		// resolution
		$('.fullwidth').css('width', vW);
		$('.fullheight').css('height', vH);
        $('.halfwidth').css('width', vW / 2);
        $('.halfheight').css('height', vH / 2);
		// $('.slant-bg-wrap, .slant-layer:first-child:before').css('max-width',
		// vW);
		// Main Menu Trigger

		$('.menu-icon-wrapper, .mobile-menu-icon-open').on('click', function() {
			$('.mobile-menu-icon-open').hide();
			$('.mobile-menu-icon-close').show();
			$('header.masthead').toggleClass('no-bgcolor');
			$('nav ul > li').find('.sub-menu').stop().hide();
			$('.menu-panel').removeClass('halfview');
			$('.sub-menu').removeClass('halfview');
			$('.mastnav').fadeToggle(500);
			$('.mastnav').toggleClass('mastnav-bordered');
		});
		$('.mobile-menu-icon-close').on('click', function(){
            $(this).hide();
            $('.mobile-menu-icon-open').show();
            $('header.masthead').toggleClass('no-bgcolor');
            $('nav ul > li').find('.sub-menu').stop().hide();
            $('.menu-panel').removeClass('halfview');
            $('.sub-menu').removeClass('halfview');
            $('.mastnav').fadeToggle(500);
            $('.mastnav').toggleClass('mastnav-bordered');
        });



	});
	// $(function ($) : ends
})();
// JSHint wrapper $(function ($) : ends