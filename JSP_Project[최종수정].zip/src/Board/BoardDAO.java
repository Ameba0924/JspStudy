﻿package Board;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class BoardDAO {
	private Connection conn;
	private PreparedStatement pstm;
	private ResultSet rs;
	
	public BoardDAO() {
		try {
			String strURL = "jdbc:mysql://localhost:3306/test";
			String dbid = "root";
			String dbpass = "toor";
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(strURL,dbid,dbpass);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public String getDate() {
		String strSQL = "select NOW()";
		try {
			pstm = conn.prepareStatement(strSQL);
			rs = pstm.executeQuery();
			if(rs.next())
				rs.getString(1);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return ""; //DB오류
	}
	
	public int getNext() {
		String strSQL = "select num from tblboard order by num desc";
		try {
			pstm = conn.prepareStatement(strSQL);
			rs = pstm.executeQuery();
			if(rs.next())
				return rs.getInt(1)+1;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return -1; //DB오류
	}
	
	public int write(String title, String name,String pass,String email,String contents) {
		String strSQL = "insert into tblboard(?,?,?,?,?,?,?,?)";
		try {
			pstm = conn.prepareStatement(strSQL);
			pstm.setInt(1, getNext());
			pstm.setString(2, name);
			pstm.setString(3, pass);
			pstm.setString(4, email);
			pstm.setString(5, title);
			pstm.setString(6,contents);
			pstm.setString(7, getDate());
			pstm.setInt(8, 0);
			rs = pstm.executeQuery();
			if(rs.next())
				return rs.getInt(1)+1;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return -1; //DB오류
	}
}
