﻿package User;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDAO {
	private Connection conn;
	private PreparedStatement pstm;
	private ResultSet rs;
	
	public UserDAO() {
		try {
			String strURL = "jdbc:mysql://localhost:3306/test";
			String dbid = "root";
			String dbpass = "toor";
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(strURL,dbid,dbpass);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public int login(String id, String pass) {
		String strSQL = "select pass from tbllogin where id=?";
		try {
			pstm = conn.prepareStatement(strSQL);
			pstm.setString(1, id);
			rs = pstm.executeQuery();
			if(rs.next()) {
				if(rs.getString(1).equals(pass))
					return 1; // 성공ㅇ
				else
					return 0; // 비밀번호 불일치
			}
			return -1; //아이디 없음
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return -2; // 걍 오류
	}
	
	public int join(User user) {
		String strSQL = "insert into tbllogin values (?,?,?,?,?,?,?,?,?,?)";
		try {
			pstm = conn.prepareStatement(strSQL);
			pstm.setString(1, user.getId());
			pstm.setString(2, user.getName());
			pstm.setString(3, user.getPass());
			pstm.setString(4, user.getJuminnum1());
			pstm.setString(5, user.getJuminnum2());
			pstm.setString(6, user.getZip());
			pstm.setString(7, user.getAddress1());
			pstm.setString(8, user.getAddress2());
			pstm.setString(9, user.getPhone());
			pstm.setString(10, user.getEmail());
			return pstm.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return -1; // 데이터베이스 오류
	}
}
